# drupal_ynh

THIS PACKAGE WAS A PROOF OF CONCEPT AND DOES NOT YET WORK

drupal cms for yunohost

* visit https://WHEREYOUINSTALLED/core/install.php to complete the installation and create the first user
* this is not ldap integrated

